namespace MoviemanytomanyWindowsFormsApp.Migrations
{
    using MoviemanytomanyWindowsFormsApp.Models;
    using System;
    using System.Data.Entity;
    using System.Data.Entity.Migrations;
    using System.Linq;

    internal sealed class Configuration : DbMigrationsConfiguration<MoviemanytomanyWindowsFormsApp.Models.MovieContext>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = false;
        }

        protected override void Seed(MoviemanytomanyWindowsFormsApp.Models.MovieContext context)
        {
            var lasseberg = new Actor { Name = "�berg, Lasse" };
            var papphamman = new Movie { Name = "Gunner pamper" };
            //var sallperson = new Movie { Name = "Sallskapresen" };


            context.Actors.AddOrUpdate(a => a.Name, lasseberg);
            context.Movies.AddOrUpdate(m=>m.Name,papphamman);
            //context.Movies.AddOrUpdate(m => m.Name, sallperson);


            context.SaveChanges();

            var movieactor = new MovieActor() {ActorId=lasseberg.ActorId,MovieId=papphamman.MovieId };
            context.MovieActors.AddOrUpdate(ma=> new { ma.ActorId, ma.MovieId },
           
            movieactor
            );
            context.SaveChanges();


        }
    }
}
