﻿using MoviemanytomanyWindowsFormsApp.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MoviemanytomanyWindowsFormsApp
{
    public partial class Form1 : Form
    {
      
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)

        {
            using (var _context = new MovieContext())
            {


                foreach (var movie in _context.Movies)
                {
                    listBox1Movie.Items.Add(movie);
                }
            }
        
        
        }

        private void listBox1Movie_SelectedIndexChanged(object sender, EventArgs e)
        {
            var movie = (Movie)listBox1Movie.SelectedItem;
            listBox2.Items.Clear();
            using (var _context = new MovieContext())
            {
                foreach (var movieactor in _context
                    .MovieActors
                    .Include("Actor")
                    .Where(ma => ma.MovieId == movie.MovieId))
                {
                    var newActor = movieactor.Actor;
                    listBox2.Items.Add(newActor);
                }
            }
            
        }

        private void nyFilmToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string movieName = Microsoft.VisualBasic.Interaction.InputBox("Ange filmens namm:");
            using (var cx=new MovieContext())
            {
                cx.Movies.Add(new Movie { Name=movieName});
                cx.SaveChanges();
            }
        }
    }
}
