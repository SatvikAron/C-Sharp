﻿using MariaDBFootballApp.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FootballWindowsFormsApp
{
    public partial class Form1 : Form
    {
        private FootballContext _context = new FootballContext();
        public Form1()
        {
            InitializeComponent();
        }

      

        private void Form1_Load(object sender, EventArgs e)
        {
            foreach (var team in _context.Teams)
            {
                comboBox1.Items.Add(team.Name);
            }
            foreach (var player in _context.Players)
            {
                comboBox2.Items.Add(player.Name);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
          var team=  _context.Teams.Add(new Team() { Name = textBox1.Text });
            _context.Teams.Add(team);
            comboBox1.Items.Add(team.Name);
            _context.SaveChanges();

            textBox1.Clear();
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            var team = _context.Teams.Single(t => t.Name == comboBox1.SelectedItem.ToString());
            var player = _context.Players.Add(new Player() { Name=textBox2.Text, Team=team });
            _context.Players.Add(player);
            comboBox2.Items.Add(player.Name);
            _context.SaveChanges();
            textBox2.Clear();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //label3.Text=
            foreach (var item in _context.Players)
            {
                MessageBox.Show($" player name is {item.Name} team name is {item.Team.Name}");
            }
        }
    }
}
