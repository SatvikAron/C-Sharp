﻿using MariaDBFootballApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MariaDBFootballApp
{
    class Program
    {
        static void Main(string[] args)
        {
           using ( var cx=new FootballContext())
            {
                var teamOne = new Team() /*{ Name = "Team One" }*/;
                cx.Teams.Add(teamOne);
               
                var aPlayer = new Player() /*{ Name = "Player One" }*/;
                cx.Players.Add(aPlayer);
                cx.SaveChanges();
                foreach (var item in cx.Players)
                {
                    Console.WriteLine($" player name is {item.Name} ");
                }


            }
            Console.ReadLine( );
        }
    }
}
