﻿using FootBallEFConsoleApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FootBallEFConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            var db = new FootballContext();
            foreach (var item in db.Players)
            {
                Console.WriteLine($" player name is {item.Name} team name is {item.Team.Name}");
            }
            Console.ReadLine();
        }
    }
}
