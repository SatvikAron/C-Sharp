﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FootBallEFConsoleApp.Models
{
  public  class Team
    {
        public int TeamId { get; set; }
        public string Name { get; set; }
        public virtual  List<Player> Players { get; set; }
        public Team()
        {
            this.Players = new List<Player>();
        }
    }
}
