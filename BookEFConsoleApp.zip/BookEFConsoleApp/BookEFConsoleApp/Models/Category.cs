﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookEFConsoleApp.Models
{
   class Category
    {
        public int CategoryId { get; set; }
        public string Name { get; set; }
        public virtual List<Book> Books { get; set; } = new List<Book>();

        //public Category()
        //{
        //    this.Books = new List<Book>();
        //}

    }
}
