﻿using BookEFConsoleApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookEFConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            using (var db = new BookContext())
            {
                var scifi = new Category { Name = "SCi Fi" };
                db.Categories.Add(scifi);
                db.SaveChanges();
                var space = new Book {Title="A space odesy"  ,Category=scifi,Price=123.50M};
                db.Books.Add(space);
                db.SaveChanges();
                foreach (var acategory in db.Categories)
                {
                    Console.WriteLine(acategory.Name);
                    foreach (var abook in acategory.Books)
                    {
                        Console.WriteLine($"Title is {abook.Title} the Price is {abook.Price}");
                    }
                }
                Console.ReadLine();
            }
            
        }
    }
}
