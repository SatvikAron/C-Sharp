﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _3App
{
    class Program
    {
        static void Main(string[] args)
        {
            System.Data.SqlClient.SqlConnection cnn = new System.Data.SqlClient.SqlConnection("Data Source=(localdb)\\MSSQLLocalDB; Database=NORTHWND");
            System.Data.SqlClient.SqlCommand command = new System.Data.SqlClient.SqlCommand("SELECT Count(EmployeeID) FROM Employees", cnn);
            cnn.Open();
            System.Data.SqlClient.SqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                Console.WriteLine(reader.GetInt32(0).ToString()); // Ho many Emploee
            }
            cnn.Close();


            Console.ReadLine();
        }
    }
}
