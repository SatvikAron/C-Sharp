﻿using System;
using System.Data.SqlClient;
namespace Upgift3
{
    class Program
    {
        static void Main(string[] args)
        {
            SqlConnection cnn = new SqlConnection("Data Source=(localdb)\\MSSQLLocalDB; Database=NORTHWND");
            SqlCommand command = new SqlCommand("SELECT * FROM Employees ", cnn);
            cnn.Open();
            SqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                Console.WriteLine(); // Empolyee lastName

            }
            cnn.Close();


            Console.ReadLine();
        }
    }
}
